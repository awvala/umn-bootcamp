# Run Test.java. 
# bash run.sh

java -cp ../../ com.shapes.Test
